﻿
Public Class Form1



    Private Sub Button18_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnthree.Click
        'txtdisplay.Text = ""
        txtdisplay.Text = txtdisplay.Text & btnthree.Text


    End Sub

    Private Sub btnone_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnone.Click
        ' txtdisplay.Text = ""

        txtdisplay.Text = txtdisplay.Text & btnone.Text


    End Sub

    Private Sub btntwo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btntwo.Click
        'txtdisplay.Text = ""
        txtdisplay.Text = txtdisplay.Text & btntwo.Text


    End Sub

    Private Sub btnfour_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnfour.Click
        ' txtdisplay.Text = ""
        txtdisplay.Text = txtdisplay.Text & btnfour.Text

    End Sub

    Private Sub btnfive_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnfive.Click
        'txtdisplay.Text = ""
        txtdisplay.Text = txtdisplay.Text & btnfive.Text

    End Sub

    Private Sub btnsix_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsix.Click
        'txtdisplay.Text = ""
        txtdisplay.Text = txtdisplay.Text & btnsix.Text
    End Sub

    Private Sub btnseven_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnseven.Click
        'txtdisplay.Text = ""
        txtdisplay.Text = txtdisplay.Text & btnseven.Text

    End Sub

    Private Sub btneight_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btneight.Click
        ' txtdisplay.Text = ""
        txtdisplay.Text = txtdisplay.Text & btneight.Text

    End Sub

    Private Sub btnnine_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnnine.Click
        'txtdisplay.Text = ""
        txtdisplay.Text = txtdisplay.Text & btnnine.Text

    End Sub

    Private Sub btnzero_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnzero.Click
        'txtdisplay.Text = ""
        txtdisplay.Text = txtdisplay.Text & btnzero.Text

    End Sub

    Private Sub btnback_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnback.Click
        txtdisplay.Text = ""

    End Sub

    Private Sub btnplus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnplus.Click
        txtdisplay.Text = txtdisplay.Text & btnplus.Text
        txtoperator.Text = btnplus.Text

        result1 = result1 + Val(txtdisplay.Text)
        txtdisplay.Clear()




    End Sub

    Private Sub btnminus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnminus.Click
        'txtdisplay.Text = txtdisplay.Text & btnminus.Text
        'txtoperator.Text = btnminus.Text


        'result1 = Val(result1) - Int(txtdisplay.Text)
        'txtdisplay.Clear()

        'txtdisplay.Text = txtdisplay.Text & btnminus.Text
        txtoperator.Text = btnminus.Text

        result1 = Val(txtdisplay.Text) - 0

        txtdisplay.Clear()


    End Sub

    Private Sub btnmul_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnmul.Click
        txtdisplay.Text = txtdisplay.Text & btnmul.Text
        txtoperator.Text = btnmul.Text
        result1 = 1

        result1 = result1 * Val(txtdisplay.Text)
        txtdisplay.Clear()


    End Sub

    Private Sub btndiv_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndiv.Click
        txtdisplay.Text = txtdisplay.Text & btndiv.Text
        txtoperator.Text = btndiv.Text
        result1 = 1


        result1 = Val(txtdisplay.Text) / result1

        txtdisplay.Clear()



    End Sub

    Private Sub btnequal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnequal.Click
        If txtoperator.Text = "+" Then
            result2 = result1 + Val(txtdisplay.Text)
            txtdisplay.Text = result2
            result1 = 0
        ElseIf txtoperator.Text = "-" Then

            result2 = result1 - Val(txtdisplay.Text)
            txtdisplay.Text = result2
            result1 = 0
        ElseIf txtoperator.Text = "*" Then
            result2 = result1 * Val(txtdisplay.Text)
            txtdisplay.Text = result2
            result1 = 0
        ElseIf txtoperator.Text = "/" Then
            result2 = result1 / Val(txtdisplay.Text)
            txtdisplay.Text = result2
            result1 = 0
       
        End If


    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        btnzero.Enabled = True
        btnone.Enabled = True
        btntwo.Enabled = True
        btnthree.Enabled = True
        btnfour.Enabled = True
        btnfive.Enabled = True
        btnsix.Enabled = True
        btnseven.Enabled = True
        btneight.Enabled = True
        btnnine.Enabled = True
        btnequal.Enabled = True
        btnplus.Enabled = True
        Button3.Enabled = True

        btnminus.Enabled = True
        btnmul.Enabled = True
        btndiv.Enabled = True
        btnsqrt.Enabled = True
        'btnper.Enabled = True
        'btnbyx.Enabled = True
        btnback.Enabled = True
        btnpt.Enabled = True
        btnpm.Enabled = True
        ' txtdisplay.Text = 0




















    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        btnzero.Enabled = False
        btnone.Enabled = False
        btntwo.Enabled = False
        btnthree.Enabled = False
        btnfour.Enabled = False
        btnfive.Enabled = False
        btnsix.Enabled = False
        btnseven.Enabled = False
        btneight.Enabled = False
        btnnine.Enabled = False
        btnequal.Enabled = False
        btnplus.Enabled = False
        btnminus.Enabled = False
        btnmul.Enabled = False
        btndiv.Enabled = False
        btnsqrt.Enabled = False
        'btnper.Enabled = False
        'btnbyx.Enabled = False
        btnback.Enabled = False
        btnpt.Enabled = False
        btnpm.Enabled = False
        Button3.Enabled = False



    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        btnzero.Enabled = False
        btnone.Enabled = False
        btntwo.Enabled = False
        btnthree.Enabled = False
        Button3.Enabled = False

        btnfour.Enabled = False
        btnfive.Enabled = False
        btnsix.Enabled = False
        btnseven.Enabled = False
        btneight.Enabled = False
        btnnine.Enabled = False
        btnequal.Enabled = False
        btnplus.Enabled = False
        btnminus.Enabled = False
        btnmul.Enabled = False
        btndiv.Enabled = False
        btnsqrt.Enabled = False
        'btnper.Enabled = False
        'btnbyx.Enabled = False
        btnback.Enabled = False
        btnpt.Enabled = False
        btnpm.Enabled = False
        txtdisplay.Text = ""



    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'result1 = Val(txtdisplay.Text)
        'txtoperator.Text = "sin"







    End Sub

    Private Sub btnpt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnpt.Click
        txtdisplay.Text = txtdisplay.Text & btnpt.Text
    End Sub

    Private Sub btnsqrt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsqrt.Click
        If txtdisplay.Text.Length <> 0 Then
            If txtdisplay.Text <> "." Then
                txtdisplay.Text = Math.Sqrt(txtdisplay.Text)
            End If
            'sign_Indicator = 1
        End If


    End Sub

    Private Sub Button3_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        If txtdisplay.Text.Length <> 0 Then
            txtdisplay.Text = txtdisplay.Text.Remove(txtdisplay.Text.Length - 1, 1)
        End If
    End Sub

    Private Sub btnper_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub btnpm_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnpm.Click
        If txtdisplay.Text.Length = 0 Then
            txtdisplay.Text = txtdisplay.Text + CStr("-")
        ElseIf txtdisplay.Text <> "." Then
            txtdisplay.Text = txtdisplay.Text * -1
        End If
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        If txtdisplay.Text.Length <> 0 Then
            If txtdisplay.Text <> "." Then
                txtdisplay.Text = Math.Sin(txtdisplay.Text)

            End If
            'sign_Indicator = 1
        End If

    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        If txtdisplay.Text.Length <> 0 Then
            If txtdisplay.Text <> "." Then
                txtdisplay.Text = Math.Cos(txtdisplay.Text)

            End If
            'sign_Indicator = 1
        End If
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        If txtdisplay.Text.Length <> 0 Then
            If txtdisplay.Text <> "." Then
                txtdisplay.Text = Math.Log10(txtdisplay.Text)

            End If
            'sign_Indicator = 1
        End If
    End Sub
End Class
