﻿Module Module1
    Public result As Integer
    Public result1 As Double
    Public result2 As Double



End Module
