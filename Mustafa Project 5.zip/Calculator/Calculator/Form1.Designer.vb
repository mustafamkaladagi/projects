﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtdisplay = New System.Windows.Forms.TextBox
        Me.btnback = New System.Windows.Forms.Button
        Me.btnseven = New System.Windows.Forms.Button
        Me.btnfour = New System.Windows.Forms.Button
        Me.btnone = New System.Windows.Forms.Button
        Me.btnzero = New System.Windows.Forms.Button
        Me.btneight = New System.Windows.Forms.Button
        Me.btnfive = New System.Windows.Forms.Button
        Me.btntwo = New System.Windows.Forms.Button
        Me.btnpm = New System.Windows.Forms.Button
        Me.btnnine = New System.Windows.Forms.Button
        Me.btnsix = New System.Windows.Forms.Button
        Me.btnthree = New System.Windows.Forms.Button
        Me.btnpt = New System.Windows.Forms.Button
        Me.btndiv = New System.Windows.Forms.Button
        Me.btnmul = New System.Windows.Forms.Button
        Me.btnminus = New System.Windows.Forms.Button
        Me.btnplus = New System.Windows.Forms.Button
        Me.btnsqrt = New System.Windows.Forms.Button
        Me.btnequal = New System.Windows.Forms.Button
        Me.txtoperator = New System.Windows.Forms.TextBox
        Me.Button1 = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.Button3 = New System.Windows.Forms.Button
        Me.Button4 = New System.Windows.Forms.Button
        Me.Button5 = New System.Windows.Forms.Button
        Me.Button6 = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'txtdisplay
        '
        Me.txtdisplay.Enabled = False
        Me.txtdisplay.Font = New System.Drawing.Font("Comic Sans MS", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdisplay.Location = New System.Drawing.Point(24, 27)
        Me.txtdisplay.Multiline = True
        Me.txtdisplay.Name = "txtdisplay"
        Me.txtdisplay.Size = New System.Drawing.Size(300, 50)
        Me.txtdisplay.TabIndex = 0
        '
        'btnback
        '
        Me.btnback.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnback.Location = New System.Drawing.Point(173, 101)
        Me.btnback.Name = "btnback"
        Me.btnback.Size = New System.Drawing.Size(80, 38)
        Me.btnback.TabIndex = 1
        Me.btnback.Text = "CLEAR"
        Me.btnback.UseVisualStyleBackColor = True
        '
        'btnseven
        '
        Me.btnseven.BackColor = System.Drawing.Color.Sienna
        Me.btnseven.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnseven.Location = New System.Drawing.Point(48, 172)
        Me.btnseven.Name = "btnseven"
        Me.btnseven.Size = New System.Drawing.Size(59, 41)
        Me.btnseven.TabIndex = 8
        Me.btnseven.Text = "7"
        Me.btnseven.UseVisualStyleBackColor = False
        '
        'btnfour
        '
        Me.btnfour.BackColor = System.Drawing.Color.Sienna
        Me.btnfour.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnfour.Location = New System.Drawing.Point(48, 219)
        Me.btnfour.Name = "btnfour"
        Me.btnfour.Size = New System.Drawing.Size(59, 40)
        Me.btnfour.TabIndex = 9
        Me.btnfour.Text = "4"
        Me.btnfour.UseVisualStyleBackColor = False
        '
        'btnone
        '
        Me.btnone.BackColor = System.Drawing.Color.Sienna
        Me.btnone.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnone.Location = New System.Drawing.Point(48, 265)
        Me.btnone.Name = "btnone"
        Me.btnone.Size = New System.Drawing.Size(59, 40)
        Me.btnone.TabIndex = 10
        Me.btnone.Text = "1"
        Me.btnone.UseVisualStyleBackColor = False
        '
        'btnzero
        '
        Me.btnzero.BackColor = System.Drawing.Color.Sienna
        Me.btnzero.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnzero.Location = New System.Drawing.Point(48, 311)
        Me.btnzero.Name = "btnzero"
        Me.btnzero.Size = New System.Drawing.Size(59, 40)
        Me.btnzero.TabIndex = 11
        Me.btnzero.Text = "0"
        Me.btnzero.UseVisualStyleBackColor = False
        '
        'btneight
        '
        Me.btneight.BackColor = System.Drawing.Color.Sienna
        Me.btneight.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btneight.Location = New System.Drawing.Point(113, 173)
        Me.btneight.Name = "btneight"
        Me.btneight.Size = New System.Drawing.Size(54, 40)
        Me.btneight.TabIndex = 12
        Me.btneight.Text = "8"
        Me.btneight.UseVisualStyleBackColor = False
        '
        'btnfive
        '
        Me.btnfive.BackColor = System.Drawing.Color.Sienna
        Me.btnfive.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnfive.Location = New System.Drawing.Point(113, 219)
        Me.btnfive.Name = "btnfive"
        Me.btnfive.Size = New System.Drawing.Size(54, 40)
        Me.btnfive.TabIndex = 13
        Me.btnfive.Text = "5"
        Me.btnfive.UseVisualStyleBackColor = False
        '
        'btntwo
        '
        Me.btntwo.BackColor = System.Drawing.Color.Sienna
        Me.btntwo.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btntwo.Location = New System.Drawing.Point(113, 264)
        Me.btntwo.Name = "btntwo"
        Me.btntwo.Size = New System.Drawing.Size(54, 41)
        Me.btntwo.TabIndex = 14
        Me.btntwo.Text = "2"
        Me.btntwo.UseVisualStyleBackColor = False
        '
        'btnpm
        '
        Me.btnpm.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnpm.Location = New System.Drawing.Point(113, 311)
        Me.btnpm.Name = "btnpm"
        Me.btnpm.Size = New System.Drawing.Size(54, 40)
        Me.btnpm.TabIndex = 15
        Me.btnpm.Text = "+/-"
        Me.btnpm.UseVisualStyleBackColor = True
        '
        'btnnine
        '
        Me.btnnine.BackColor = System.Drawing.Color.Sienna
        Me.btnnine.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnnine.Location = New System.Drawing.Point(173, 173)
        Me.btnnine.Name = "btnnine"
        Me.btnnine.Size = New System.Drawing.Size(54, 40)
        Me.btnnine.TabIndex = 16
        Me.btnnine.Text = "9"
        Me.btnnine.UseVisualStyleBackColor = False
        '
        'btnsix
        '
        Me.btnsix.BackColor = System.Drawing.Color.Sienna
        Me.btnsix.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsix.Location = New System.Drawing.Point(173, 220)
        Me.btnsix.Name = "btnsix"
        Me.btnsix.Size = New System.Drawing.Size(54, 39)
        Me.btnsix.TabIndex = 17
        Me.btnsix.Text = "6"
        Me.btnsix.UseVisualStyleBackColor = False
        '
        'btnthree
        '
        Me.btnthree.BackColor = System.Drawing.Color.Sienna
        Me.btnthree.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnthree.Location = New System.Drawing.Point(173, 264)
        Me.btnthree.Name = "btnthree"
        Me.btnthree.Size = New System.Drawing.Size(54, 39)
        Me.btnthree.TabIndex = 18
        Me.btnthree.Text = "3"
        Me.btnthree.UseVisualStyleBackColor = False
        '
        'btnpt
        '
        Me.btnpt.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnpt.Location = New System.Drawing.Point(173, 311)
        Me.btnpt.Name = "btnpt"
        Me.btnpt.Size = New System.Drawing.Size(54, 41)
        Me.btnpt.TabIndex = 19
        Me.btnpt.Text = "."
        Me.btnpt.UseVisualStyleBackColor = True
        '
        'btndiv
        '
        Me.btndiv.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btndiv.Location = New System.Drawing.Point(233, 173)
        Me.btndiv.Name = "btndiv"
        Me.btndiv.Size = New System.Drawing.Size(54, 40)
        Me.btndiv.TabIndex = 20
        Me.btndiv.Text = "/"
        Me.btndiv.UseVisualStyleBackColor = True
        '
        'btnmul
        '
        Me.btnmul.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnmul.Location = New System.Drawing.Point(233, 220)
        Me.btnmul.Name = "btnmul"
        Me.btnmul.Size = New System.Drawing.Size(54, 41)
        Me.btnmul.TabIndex = 21
        Me.btnmul.Text = "*"
        Me.btnmul.UseVisualStyleBackColor = True
        '
        'btnminus
        '
        Me.btnminus.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnminus.Location = New System.Drawing.Point(233, 267)
        Me.btnminus.Name = "btnminus"
        Me.btnminus.Size = New System.Drawing.Size(54, 40)
        Me.btnminus.TabIndex = 22
        Me.btnminus.Text = "-"
        Me.btnminus.UseVisualStyleBackColor = True
        '
        'btnplus
        '
        Me.btnplus.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnplus.Location = New System.Drawing.Point(233, 313)
        Me.btnplus.Name = "btnplus"
        Me.btnplus.Size = New System.Drawing.Size(54, 78)
        Me.btnplus.TabIndex = 23
        Me.btnplus.Text = "+"
        Me.btnplus.UseVisualStyleBackColor = True
        '
        'btnsqrt
        '
        Me.btnsqrt.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsqrt.Location = New System.Drawing.Point(293, 173)
        Me.btnsqrt.Name = "btnsqrt"
        Me.btnsqrt.Size = New System.Drawing.Size(58, 40)
        Me.btnsqrt.TabIndex = 24
        Me.btnsqrt.Text = "sqrt"
        Me.btnsqrt.UseVisualStyleBackColor = True
        '
        'btnequal
        '
        Me.btnequal.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnequal.Location = New System.Drawing.Point(293, 220)
        Me.btnequal.Name = "btnequal"
        Me.btnequal.Size = New System.Drawing.Size(58, 171)
        Me.btnequal.TabIndex = 27
        Me.btnequal.Text = "="
        Me.btnequal.UseVisualStyleBackColor = True
        '
        'txtoperator
        '
        Me.txtoperator.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtoperator.Location = New System.Drawing.Point(330, 30)
        Me.txtoperator.Name = "txtoperator"
        Me.txtoperator.Size = New System.Drawing.Size(67, 47)
        Me.txtoperator.TabIndex = 28
        Me.txtoperator.Visible = False
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(259, 101)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(48, 40)
        Me.Button1.TabIndex = 29
        Me.Button1.Text = "ON"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(313, 101)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(54, 40)
        Me.Button2.TabIndex = 30
        Me.Button2.Text = "OFF"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(45, 101)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(122, 38)
        Me.Button3.TabIndex = 31
        Me.Button3.Text = "BACKSPACE"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(48, 357)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(59, 34)
        Me.Button4.TabIndex = 32
        Me.Button4.Text = "Sin"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(113, 358)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(54, 34)
        Me.Button5.TabIndex = 33
        Me.Button5.Text = "Cos"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(173, 357)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(59, 34)
        Me.Button6.TabIndex = 34
        Me.Button6.Text = "log"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(408, 467)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.txtoperator)
        Me.Controls.Add(Me.btnequal)
        Me.Controls.Add(Me.btnsqrt)
        Me.Controls.Add(Me.btnplus)
        Me.Controls.Add(Me.btnminus)
        Me.Controls.Add(Me.btnmul)
        Me.Controls.Add(Me.btndiv)
        Me.Controls.Add(Me.btnpt)
        Me.Controls.Add(Me.btnthree)
        Me.Controls.Add(Me.btnsix)
        Me.Controls.Add(Me.btnnine)
        Me.Controls.Add(Me.btnpm)
        Me.Controls.Add(Me.btntwo)
        Me.Controls.Add(Me.btnfive)
        Me.Controls.Add(Me.btneight)
        Me.Controls.Add(Me.btnzero)
        Me.Controls.Add(Me.btnone)
        Me.Controls.Add(Me.btnfour)
        Me.Controls.Add(Me.btnseven)
        Me.Controls.Add(Me.btnback)
        Me.Controls.Add(Me.txtdisplay)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtdisplay As System.Windows.Forms.TextBox
    Friend WithEvents btnback As System.Windows.Forms.Button
    Friend WithEvents btnseven As System.Windows.Forms.Button
    Friend WithEvents btnfour As System.Windows.Forms.Button
    Friend WithEvents btnone As System.Windows.Forms.Button
    Friend WithEvents btnzero As System.Windows.Forms.Button
    Friend WithEvents btneight As System.Windows.Forms.Button
    Friend WithEvents btnfive As System.Windows.Forms.Button
    Friend WithEvents btntwo As System.Windows.Forms.Button
    Friend WithEvents btnpm As System.Windows.Forms.Button
    Friend WithEvents btnnine As System.Windows.Forms.Button
    Friend WithEvents btnsix As System.Windows.Forms.Button
    Friend WithEvents btnthree As System.Windows.Forms.Button
    Friend WithEvents btnpt As System.Windows.Forms.Button
    Friend WithEvents btndiv As System.Windows.Forms.Button
    Friend WithEvents btnmul As System.Windows.Forms.Button
    Friend WithEvents btnminus As System.Windows.Forms.Button
    Friend WithEvents btnplus As System.Windows.Forms.Button
    Friend WithEvents btnsqrt As System.Windows.Forms.Button
    Friend WithEvents btnequal As System.Windows.Forms.Button
    Friend WithEvents txtoperator As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button

End Class
