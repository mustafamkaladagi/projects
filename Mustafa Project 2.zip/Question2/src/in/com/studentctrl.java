package in.com;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import in.com.student;

/**
 * Servlet implementation class studentctrl
 */
@WebServlet("/studentctrl")
public class studentctrl extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public studentctrl() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String rol=request.getParameter("i");
		int roll=Integer.parseInt(rol);
		String ag=request.getParameter("a");
		int age=Integer.parseInt(ag);
		String name=request.getParameter("n");
		String gender=request.getParameter("g");
		String city=request.getParameter("c");
		
				
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		
		SessionFactory sf=cfg.buildSessionFactory();
		org.hibernate.Session s=sf.openSession();
				
		//s.setId(Integer.parseInt(id));
		Transaction tx=s.beginTransaction();
				
		student st=new student();
		
		st.setRoll(roll);
		st.setAge(age);
		st.setName(name);
		st.setGender(gender);
		st.setCity(city);
		s.save(st);
		
		RequestDispatcher rd=request.getRequestDispatcher("addstudent.jsp");
		request.setAttribute("msg","Data Saved Successfully");
		rd.include(request, response);
		rd.forward(request, response);
		
		
		tx.commit();
		s.close();
		sf.close();
	}

}
