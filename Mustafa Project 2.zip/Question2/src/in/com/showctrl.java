package in.com;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import in.com.student;

/**
 * Servlet implementation class showctrl
 */
@WebServlet("/showctrl")
public class showctrl extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public showctrl() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");	
		
		String optio=request.getParameter("nm");
		
		int option=Integer.parseInt(optio);
		
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		
		SessionFactory sf=cfg.buildSessionFactory();
		org.hibernate.Session s=sf.openSession();
				
		//s.setId(Integer.parseInt(id));
		Transaction tx=s.beginTransaction();
		
		if(option>0)
		{
			String hql = "FROM student E WHERE E.roll = '"+option+"'";
			//String hql="from student order by id";
		    Query query=s.createQuery(hql);
			List<student> list=query.list();

			out.println("<center>");
			out.print("<table border=1>");
			for(student d:list)
			{
				
				out.print("*************Your Detalis are***********");
				out.println("<tr><td>"+d.getRoll()+"</td><td>"+d.getAge()+"</td><td>"+"</td><td>"+d.getName()+"</td><td>"+d.getGender()+"</td><td>"+d.getCity()+"</td></tr>");
				
			}
			out.println("</table>");
			out.println("</center>");
		}
		else
		{
			out.println("Record not found");
		}
		tx.commit();
		s.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
